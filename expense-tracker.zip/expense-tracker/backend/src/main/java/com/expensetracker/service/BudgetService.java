package com.expensetracker.service;

import com.expensetracker.model.Budget;
import com.expensetracker.repository.BudgetRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class BudgetService {

    private final BudgetRepository budgetRepository;

    public List<Budget> getAllBudgets() {
        return budgetRepository.findAll();
    }

    public Optional<Budget> getBudgetById(Long id) {
        return budgetRepository.findById(id);
    }

    public Optional<Budget> getBudgetByCategory(String category) {
        return budgetRepository.findByCategoryIgnoreCase(category);
    }

    public Budget createBudget(Budget budget) {
        if (budgetRepository.existsByCategoryIgnoreCase(budget.getCategory())) {
            throw new RuntimeException("Budget for category '" + budget.getCategory() + "' already exists");
        }
        return budgetRepository.save(budget);
    }

    public Budget updateBudget(Long id, Budget updated) {
        return budgetRepository.findById(id).map(existing -> {
            existing.setBudgetLimit(updated.getBudgetLimit());
            existing.setMonthYear(updated.getMonthYear());
            return budgetRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Budget not found with id: " + id));
    }

    public void deleteBudget(Long id) {
        if (!budgetRepository.existsById(id)) {
            throw new RuntimeException("Budget not found with id: " + id);
        }
        budgetRepository.deleteById(id);
    }
}
