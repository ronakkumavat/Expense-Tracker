package com.expensetracker.service;

import com.expensetracker.model.Expense;
import com.expensetracker.repository.ExpenseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional
public class ExpenseService {

    private final ExpenseRepository expenseRepository;

    // ── CRUD ──────────────────────────────────────────────────────────────────

    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll(
                org.springframework.data.domain.Sort.by(
                        org.springframework.data.domain.Sort.Direction.DESC, "date"));
    }

    public Optional<Expense> getExpenseById(Long id) {
        return expenseRepository.findById(id);
    }

    public Expense createExpense(Expense expense) {
        return expenseRepository.save(expense);
    }

    public Expense updateExpense(Long id, Expense updated) {
        return expenseRepository.findById(id).map(existing -> {
            existing.setTitle(updated.getTitle());
            existing.setDescription(updated.getDescription());
            existing.setAmount(updated.getAmount());
            existing.setDate(updated.getDate());
            existing.setCategory(updated.getCategory());
            existing.setPaymentMethod(updated.getPaymentMethod());
            existing.setTags(updated.getTags());
            return expenseRepository.save(existing);
        }).orElseThrow(() -> new RuntimeException("Expense not found with id: " + id));
    }

    public void deleteExpense(Long id) {
        if (!expenseRepository.existsById(id)) {
            throw new RuntimeException("Expense not found with id: " + id);
        }
        expenseRepository.deleteById(id);
    }

    // ── FILTERS ───────────────────────────────────────────────────────────────

    public List<Expense> getExpensesByCategory(String category) {
        return expenseRepository.findByCategoryIgnoreCase(category);
    }

    public List<Expense> getExpensesByDateRange(LocalDate start, LocalDate end) {
        return expenseRepository.findByDateBetweenOrderByDateDesc(start, end);
    }

    public List<Expense> getExpensesByMonth(int month, int year) {
        return expenseRepository.findByMonthAndYear(month, year);
    }

    public List<Expense> searchExpenses(String keyword) {
        return expenseRepository.searchByKeyword(keyword);
    }

    public List<Expense> getRecentExpenses() {
        return expenseRepository.findTop5ByOrderByCreatedAtDesc();
    }

    // ── STATISTICS ────────────────────────────────────────────────────────────

    public BigDecimal getTotalExpenses() {
        return expenseRepository.getTotalExpenses();
    }

    public BigDecimal getTotalExpensesForMonth(int month, int year) {
        return expenseRepository.getTotalExpensesForMonth(month, year);
    }

    public Map<String, BigDecimal> getTotalByCategory() {
        List<Object[]> rows = expenseRepository.getTotalByCategory();
        Map<String, BigDecimal> result = new LinkedHashMap<>();
        for (Object[] row : rows) {
            result.put((String) row[0], (BigDecimal) row[1]);
        }
        return result;
    }

    public Map<String, BigDecimal> getTotalByCategoryForMonth(int month, int year) {
        List<Object[]> rows = expenseRepository.getTotalByCategoryForMonth(month, year);
        Map<String, BigDecimal> result = new LinkedHashMap<>();
        for (Object[] row : rows) {
            result.put((String) row[0], (BigDecimal) row[1]);
        }
        return result;
    }

    public List<Map<String, Object>> getTotalByMonth() {
        List<Object[]> rows = expenseRepository.getTotalByMonth();
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object[] row : rows) {
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("month", row[0]);
            entry.put("year", row[1]);
            entry.put("total", row[2]);
            result.add(entry);
        }
        return result;
    }

    public Map<String, Object> getDashboardStats() {
        LocalDate now = LocalDate.now();
        int month = now.getMonthValue();
        int year = now.getYear();

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalAllTime", getTotalExpenses());
        stats.put("totalThisMonth", getTotalExpensesForMonth(month, year));
        stats.put("categoryBreakdown", getTotalByCategory());
        stats.put("monthlyBreakdown", getTotalByMonth());
        stats.put("recentExpenses", getRecentExpenses());
        return stats;
    }
}
